﻿namespace TreeViewFileExplorer.Enums
{
    public enum ItemType
    {
        Drive,
        Folder,
        File
    }
}
