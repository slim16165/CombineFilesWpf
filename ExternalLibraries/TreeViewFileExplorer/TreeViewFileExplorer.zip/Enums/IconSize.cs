﻿namespace TreeViewFileExplorer.Enums
{
    public enum IconSize : short
    {
        Small,
        Large
    }
}
