﻿namespace TreeViewFileExplorer.Enums
{
    public enum FileAttribute : uint
    {
        Directory = 16,
        File = 256
    }
}
