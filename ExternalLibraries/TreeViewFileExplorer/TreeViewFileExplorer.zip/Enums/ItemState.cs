﻿namespace TreeViewFileExplorer.Enums
{
    public enum ItemState : short
    {
        Undefined,
        Open,
        Close
    }
}
