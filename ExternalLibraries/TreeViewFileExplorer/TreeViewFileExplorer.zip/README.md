
## TreeViewFileExplorer

Just to support my old blog (6 years ago):

### Links
 
 - http://codesdirectory.blogspot.com/2013/01/c-wpf-treeview-file-explorer.html
 - http://codesdirectory.blogspot.com/2013/01/part-2-c-wpf-treeview-file-explorer.html
 - http://codesdirectory.blogspot.com/2013/01/displaying-system-icon-in-c-wpf.html

### Details

A customized WPF TreeView File Explorer.

<img src="https://github.com/mikependon/Tutorials/blob/master/WPF/TreeViewFileExplorer/Images/TVFE.PNG" />
